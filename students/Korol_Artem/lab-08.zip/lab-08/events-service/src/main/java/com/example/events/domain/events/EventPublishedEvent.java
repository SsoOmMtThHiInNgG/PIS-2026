package com.example.events.domain.events;

public class EventPublishedEvent {
    
}
