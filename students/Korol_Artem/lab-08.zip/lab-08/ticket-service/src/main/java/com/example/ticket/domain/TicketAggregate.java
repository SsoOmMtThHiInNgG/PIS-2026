public class TicketAggregate {
    
}
