public class TicketView {
    
}
