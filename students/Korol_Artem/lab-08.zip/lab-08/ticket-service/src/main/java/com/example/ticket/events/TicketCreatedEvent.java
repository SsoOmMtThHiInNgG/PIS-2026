public class TicketCreatedEvent {
    
}
