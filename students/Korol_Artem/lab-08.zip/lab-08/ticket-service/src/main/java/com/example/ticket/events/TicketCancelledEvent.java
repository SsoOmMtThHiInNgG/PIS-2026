public class TicketCancelledEvent {
    
}
