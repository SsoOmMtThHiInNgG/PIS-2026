public class TicketActivatedEvent {
    
}
