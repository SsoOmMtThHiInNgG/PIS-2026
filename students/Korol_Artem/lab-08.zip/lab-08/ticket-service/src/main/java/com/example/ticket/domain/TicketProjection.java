public class TicketProjection {
    
}
